import { type SharedValue } from 'react-native-reanimated';
import type { ViewStyle } from 'react-native';
import type { TAnimation, TDirection, TGestureEdge } from './types';
export interface GestureBounds {
    left: number;
    top: number;
    right: number;
    bottom: number;
}
export interface GestureEdgeOffsets {
    left: number;
    right: number;
    top: number;
    bottom: number;
}
export interface GestureEdgeMatch {
    axis: TDirection;
    sign: -1 | 1;
}
export declare const getGestureEdge: (x: number, y: number, bounds: GestureBounds, edges: readonly TGestureEdge[], offsets: GestureEdgeOffsets) => GestureEdgeMatch | null;
export declare const getAnimationConfig: (progress: SharedValue<number>, direction: TDirection, width: number, height: number) => Record<TAnimation, ViewStyle>;
//# sourceMappingURL=utils.d.ts.map