import { useEffect, useRef, type PropsWithChildren } from 'react';
import type { ReactElement } from 'react';
import { StyleSheet, type StyleProp, type ViewStyle } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
} from 'react-native-reanimated';
import type { SharedElementNode, SharedElementRect } from './types';
import { useSharedElementRegistry } from '../../hooks/use-shared-element-registry';
import { NativeSharedElement } from '../../native/epic-shared-element';

export interface SharedElementProps {
  id: string;
  measurementOnly?: boolean;
  /** Minimum interval between native frame events, in milliseconds. */
  throttle?: number;
  /** Enables continuous native frame tracking for scrolling ancestors. */
  trackFrame?: boolean;
  style?: StyleProp<ViewStyle>;
}

export function SharedElement({
  id,
  measurementOnly = false,
  throttle = 16,
  trackFrame = false,
  style,
  children,
}: PropsWithChildren<SharedElementProps & { children: ReactElement }>) {
  const { register, updateRect, unregister } = useSharedElementRegistry();
  const rect = useSharedValue<SharedElementRect | null>(null);
  const visibility = useSharedValue(1);
  const nodeRef = useRef<SharedElementNode | null>(null);
  const visibilityStyle = useAnimatedStyle(() => ({
    opacity: visibility.value,
  }));

  useEffect(() => {
    const node: SharedElementNode = {
      id,
      measurementOnly,
      rect,
      visibility,
    };
    nodeRef.current = node;
    register(node);

    return () => {
      if (nodeRef.current === node) {
        nodeRef.current = null;
      }
      unregister(node);
    };
  }, [id, measurementOnly, rect, register, unregister, visibility]);

  const elementStyle = [style, measurementOnly && styles.shadow];

  return (
    <AnimatedNativeSharedElement
      collapsable={false}
      pointerEvents={measurementOnly ? 'none' : 'auto'}
      throttle={throttle}
      trackFrame={trackFrame}
      style={[visibilityStyle, elementStyle]}
      onFrame={(event) => {
        const node = nodeRef.current;
        if (node) {
          updateRect(node, event.nativeEvent);
        }
      }}
    >
      {children}
    </AnimatedNativeSharedElement>
  );
}

const AnimatedNativeSharedElement =
  Animated.createAnimatedComponent(NativeSharedElement);

const styles = StyleSheet.create({
  shadow: {
    opacity: 0,
  },
});

export type { SharedElementRect } from './types';
