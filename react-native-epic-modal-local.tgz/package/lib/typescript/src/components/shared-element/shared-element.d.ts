import { type PropsWithChildren } from 'react';
import type { ReactElement } from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
export interface SharedElementProps {
    id: string;
    measurementOnly?: boolean;
    /** Minimum interval between native frame events, in milliseconds. */
    throttle?: number;
    /** Enables continuous native frame tracking for scrolling ancestors. */
    trackFrame?: boolean;
    style?: StyleProp<ViewStyle>;
}
export declare function SharedElement({ id, measurementOnly, throttle, trackFrame, style, children, }: PropsWithChildren<SharedElementProps & {
    children: ReactElement;
}>): import("react/jsx-runtime").JSX.Element;
export type { SharedElementRect } from './types';
//# sourceMappingURL=shared-element.d.ts.map