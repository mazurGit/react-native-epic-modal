export declare const useProgress: () => import("react-native-reanimated").SharedValue<number>;
//# sourceMappingURL=use-progress.d.ts.map