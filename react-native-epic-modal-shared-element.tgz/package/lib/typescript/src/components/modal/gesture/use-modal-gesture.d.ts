import { type GestureType } from 'react-native-gesture-handler';
import { type SharedValue } from 'react-native-reanimated';
import { type ModalGestureConfig } from './modal-gesture';
import { type ModalGestureRuntime } from './modal-gesture-runtime';
type UseModalGestureOptions = {
    progress: SharedValue<number>;
    config?: ModalGestureConfig;
    onDismissRequest?: () => void;
};
type ModalGestureState = Pick<ModalGestureRuntime, 'gestureActive' | 'translationX' | 'translationY'> & {
    gesture: GestureType;
};
export declare const useModalGesture: ({ progress, config, onDismissRequest, }: UseModalGestureOptions) => ModalGestureState;
export {};
//# sourceMappingURL=use-modal-gesture.d.ts.map