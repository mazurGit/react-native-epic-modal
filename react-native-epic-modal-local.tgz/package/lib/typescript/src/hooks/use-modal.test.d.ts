export {};
//# sourceMappingURL=use-modal.test.d.ts.map