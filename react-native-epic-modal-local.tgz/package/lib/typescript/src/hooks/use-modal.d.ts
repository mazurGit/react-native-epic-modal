import type { IModalComponent, IModalRegistry } from '../components/modal/types';
export declare const registerModalById: (state: IModalRegistry, modal: IModalComponent) => {
    byId: {
        [x: string]: IModalComponent;
    };
    order: string[];
};
export declare const removeModalById: (state: IModalRegistry, id: string) => IModalRegistry;
export declare const updateModalById: (state: IModalRegistry, id: string, props: IModalComponent["props"]) => IModalRegistry;
export declare const useModal: () => {
    registerModal: (modal: IModalComponent) => void;
    updateModal: (id: string, props: IModalComponent["props"]) => void;
    removeModal: (id: string) => void;
};
//# sourceMappingURL=use-modal.d.ts.map