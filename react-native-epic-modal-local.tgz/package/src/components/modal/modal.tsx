import {
  forwardRef,
  useContext,
  useCallback,
  useImperativeHandle,
  useEffect,
  useRef,
  useState,
  useMemo,
  type PropsWithChildren,
} from 'react';
import type { LayoutChangeEvent } from 'react-native';
import type { IModalProps, IModalRef } from './types';
import { StatusBar, StyleSheet, View } from 'react-native';
import { scheduleOnRN } from 'react-native-worklets';
import Animated, {
  useAnimatedStyle,
  useAnimatedReaction,
  useDerivedValue,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { useWindowDimensions } from 'react-native';
import { DEFAULT_ANIMATION_CONFIG, DEFAULT_GESTURE_CONFIG } from './constants';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import { getAnimationConfig, getGestureEdge } from './utils';
import { ModalBackHandlerProvider } from '../../context/context';
import { ModalProgressContext } from '../../context/modal-progress-context';
import {
  ModalTransitionContext,
  type ModalTransitionDescriptor,
} from '../../context/modal-transition-context';
import { SharedElementTransitionView } from '../shared-element/shared-element-transition';

export const ModalContent = forwardRef<
  IModalRef,
  PropsWithChildren<IModalProps>
>(
  (
    {
      animationConfig = DEFAULT_ANIMATION_CONFIG,
      animationDirection = 'horizontal',
      gestureEnabled = true,
      children,
      id,
      priority,
      style,
      onDismiss,
      onEnter,
      animation = 'fade',
      gestureConfig = DEFAULT_GESTURE_CONFIG,
      hiddenStatusBar = false,
    },
    ref
  ) => {
    const resolvedGestureConfig = {
      ...DEFAULT_GESTURE_CONFIG,
      ...gestureConfig,
    };
    const {
      swipeProgressToClose,
      swipeVelocityThreshold,
      leftGestureAreaOffset,
      topGestureAreaOffset,
      rightGestureAreaOffset,
      bottomGestureAreaOffset,
      gestureEdges,
      edgeTarget,
    } = resolvedGestureConfig;

    const [visible, setVisible] = useState(false);
    const [transitions, setTransitions] = useState<ModalTransitionDescriptor[]>(
      []
    );
    const visibleRef = useRef(false);
    const { width, height } = useWindowDimensions();
    const containerWidth = useSharedValue(0);
    const containerHeight = useSharedValue(0);
    const contentX = useSharedValue(0);
    const contentY = useSharedValue(0);
    const backHandler = useContext(ModalBackHandlerProvider);
    const sensitiveAreaTouched = useSharedValue(false);
    const gestureAxis = useSharedValue(0);
    const gestureEdgeSign = useSharedValue(1);
    const progress = useSharedValue(0);
    const animationVersion = useSharedValue(0);
    const presented = useSharedValue(false);
    const closing = useSharedValue(false);
    const hideRequest = useSharedValue(0);
    const showRequestRef = useRef(0);
    const canSwipe = useDerivedValue(
      () => sensitiveAreaTouched.value && gestureEnabled && !closing.value,
      [closing, gestureEnabled]
    );

    const hideWithAnimation = useCallback(() => {
      showRequestRef.current += 1;
      hideRequest.value += 1;
    }, [hideRequest]);

    const registerTransition = useCallback(
      (transition: ModalTransitionDescriptor) => {
        setTransitions((current) => {
          const index = current.findIndex(({ key }) => key === transition.key);
          if (index === -1) return [...current, transition];
          const next = current.slice();
          next[index] = transition;
          return next;
        });
      },
      []
    );
    const unregisterTransition = useCallback((key: string) => {
      setTransitions((current) =>
        current.filter((transition) => transition.key !== key)
      );
    }, []);
    const transitionContext = useMemo(
      () => ({
        register: registerTransition,
        unregister: unregisterTransition,
      }),
      [registerTransition, unregisterTransition]
    );

    useAnimatedReaction(
      () => hideRequest.value,
      (request, previousRequest) => {
        if (request === 0 || request === previousRequest) return;
        if (!presented.value || closing.value) return;
        closing.value = true;
        const version = animationVersion.value + 1;
        animationVersion.value = version;
        progress.value = withSpring(0, animationConfig, (finished) => {
          if (!finished || animationVersion.value !== version) return;
          presented.value = false;
          closing.value = false;
          scheduleOnRN(setVisible, false);
          if (onDismiss) scheduleOnRN(onDismiss);
        });
      },
      [animationConfig, onDismiss]
    );

    useImperativeHandle(
      ref,
      () => ({
        show: () => {
          animationVersion.value += 1;
          const request = ++showRequestRef.current;
          presented.value = true;
          closing.value = false;
          progress.value = 0;
          setVisible(true);
          onEnter?.();
          requestAnimationFrame(() => {
            if (showRequestRef.current !== request) {
              return;
            }
            requestAnimationFrame(() => {
              if (showRequestRef.current !== request) {
                return;
              }
              progress.value = withSpring(1, animationConfig);
            });
          });
        },
        hide: hideWithAnimation,
      }),
      [
        animationVersion,
        animationConfig,
        hideWithAnimation,
        onEnter,
        presented,
        progress,
        closing,
      ]
    );

    const onBackPress = useCallback(() => {
      if (!visibleRef.current) {
        return false;
      }
      hideWithAnimation();
      return true;
    }, [hideWithAnimation]);

    useEffect(() => {
      visibleRef.current = visible;
    }, [visible]);

    useEffect(() => {
      if (!backHandler) return;
      return backHandler.register(id ?? 'modal', priority ?? 1, onBackPress);
    }, [backHandler, id, onBackPress, priority]);

    const pan = Gesture.Pan()
      .minDistance(1)
      .onStart((event) => {
        'worklet';
        const left = edgeTarget === 'content' ? contentX.value : 0;
        const top = edgeTarget === 'content' ? contentY.value : 0;
        const right =
          edgeTarget === 'content'
            ? contentX.value + containerWidth.value
            : width;
        const bottom =
          edgeTarget === 'content'
            ? contentY.value + containerHeight.value
            : height;
        const edge = getGestureEdge(
          event.x,
          event.y,
          { left, top, right, bottom },
          gestureEdges,
          {
            left: leftGestureAreaOffset,
            right: rightGestureAreaOffset,
            top: topGestureAreaOffset,
            bottom: bottomGestureAreaOffset,
          }
        );
        gestureEdgeSign.value = edge?.sign ?? 1;
        gestureAxis.value = edge?.axis === 'vertical' ? 1 : 0;
        sensitiveAreaTouched.value = edge !== null;
      })
      .onUpdate((event) => {
        'worklet';
        if (!canSwipe.value) {
          return;
        }
        const isHorizontalGesture = gestureAxis.value === 0;
        const distance = isHorizontalGesture
          ? containerWidth.value || width
          : containerHeight.value || height;
        const translation = isHorizontalGesture
          ? event.translationX
          : event.translationY;
        const edgeTranslation = translation * gestureEdgeSign.value;
        const swipeProgress = 1 - Math.max(edgeTranslation, 0) / distance;
        progress.value = Math.min(Math.max(swipeProgress, 0), 1);
      })
      .onEnd((event) => {
        'worklet';
        const swipeVelocity =
          (gestureAxis.value === 0 ? event.velocityX : event.velocityY) *
          gestureEdgeSign.value;
        if (
          progress.value < Number(swipeProgressToClose) ||
          swipeVelocity > swipeVelocityThreshold
        ) {
          if (closing.value) return;
          closing.value = true;
          const version = animationVersion.value + 1;
          animationVersion.value = version;
          progress.value = withSpring(0, animationConfig, () => {
            if (animationVersion.value === version && presented.value) {
              presented.value = false;
              closing.value = false;
              scheduleOnRN(setVisible, false);
              if (onDismiss) scheduleOnRN(onDismiss);
            }
          });
        } else {
          progress.value = withSpring(1, animationConfig);
        }
      });

    const aStyles = useAnimatedStyle(
      () =>
        getAnimationConfig(
          progress,
          animationDirection,
          containerWidth.value || width,
          containerHeight.value || height
        )[animation],
      [animation, animationDirection, height, width]
    );
    const onLayout = useCallback(
      ({ nativeEvent: { layout } }: LayoutChangeEvent) => {
        contentX.value = layout.x;
        contentY.value = layout.y;
        containerWidth.value = layout.width;
        containerHeight.value = layout.height;
      },
      [containerHeight, containerWidth, contentX, contentY]
    );

    if (!visible) {
      return null;
    }

    return (
      <ModalTransitionContext.Provider value={transitionContext}>
        <StatusBar hidden={hiddenStatusBar} />
        <GestureDetector gesture={pan}>
          <View style={StyleSheet.absoluteFill}>
            <View pointerEvents="auto" style={StyleSheet.absoluteFill} />
            <>
              <Animated.View
                onLayout={onLayout}
                style={[
                  style ?? StyleSheet.absoluteFill,
                  { zIndex: priority },
                  aStyles,
                ]}
              >
                <ModalProgressContext.Provider value={progress}>
                  {children}
                </ModalProgressContext.Provider>
              </Animated.View>
              <View
                pointerEvents="box-none"
                style={[StyleSheet.absoluteFill, styles.transitionContainer]}
              >
                {transitions.map(({ key, ...transition }) => (
                  <SharedElementTransitionView key={key} {...transition} />
                ))}
              </View>
            </>
          </View>
        </GestureDetector>
      </ModalTransitionContext.Provider>
    );
  }
);

const styles = StyleSheet.create({
  transitionContainer: {
    zIndex: 1000,
  },
});
