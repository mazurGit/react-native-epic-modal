import {
  useCallback,
  useMemo,
  useRef,
  useState,
  type FC,
  type PropsWithChildren,
} from 'react';
import {
  ModalBackHandlerProvider,
  ModalSetStateProvider,
  ModalStateProvider,
} from '../../context/context';
import { SharedElementContext } from '../../context/shared-element-context';
import type {
  SharedElementNode,
  SharedElementRect,
} from '../shared-element/types';
import { useAndroidBackHandler } from '../../hooks/use-android-back-handler';
import { ModalHost } from '../modal-host/modal-host';
import type { IModalRegistry } from '../modal/types';

export const ModalProvider: FC<PropsWithChildren> = ({ children }) => {
  const [state, setState] = useState<IModalRegistry>({
    byId: {},
    order: [],
  });
  const [sharedElementState, setSharedElementState] = useState(() => ({
    revision: 0,
  }));
  const sharedElementNodes = useRef(new Map<string, SharedElementNode>());
  const registerSharedElement = useCallback((node: SharedElementNode) => {
    const nodeKey = `${node.id}:${node.measurementOnly ? 'measurement' : 'content'}`;
    const existing = sharedElementNodes.current.get(nodeKey);
    if (existing && existing !== node) {
      if (__DEV__) {
        console.error(
          `[SharedElementRegistry] Duplicate id "${node.id}" ignored. ` +
            'Shared element ids must be unique.'
        );
      }
      return;
    }
    sharedElementNodes.current.set(nodeKey, node);
    setSharedElementState((current) => ({
      revision: current.revision + 1,
    }));
  }, []);
  const updateSharedElementRect = useCallback(
    (node: SharedElementNode, rect: SharedElementRect) => {
      const nodeKey = `${node.id}:${node.measurementOnly ? 'measurement' : 'content'}`;
      if (sharedElementNodes.current.get(nodeKey) === node) {
        node.rect.value = rect;
      }
    },
    []
  );
  const unregisterSharedElement = useCallback((node: SharedElementNode) => {
    const nodeKey = `${node.id}:${node.measurementOnly ? 'measurement' : 'content'}`;
    if (sharedElementNodes.current.get(nodeKey) !== node) return;
    sharedElementNodes.current.delete(nodeKey);
    setSharedElementState((current) => ({
      revision: current.revision + 1,
    }));
  }, []);
  const sharedElementContext = useMemo(
    () => ({
      get: (id: string, measurementOnly = false) =>
        sharedElementNodes.current.get(
          `${id}:${measurementOnly ? 'measurement' : 'content'}`
        ),
      register: registerSharedElement,
      updateRect: updateSharedElementRect,
      unregister: unregisterSharedElement,
      revision: sharedElementState.revision,
    }),
    [
      registerSharedElement,
      sharedElementState,
      unregisterSharedElement,
      updateSharedElementRect,
    ]
  );
  const handlers = useRef(
    new Map<
      string,
      { priority: number; order: number; handler: () => boolean }
    >()
  );
  const order = useRef(0);
  const registerBackHandler = useCallback(
    (id: string, priority: number, handler: () => boolean) => {
      const entry = { priority, order: order.current++, handler };
      handlers.current.set(id, entry);
      return () => {
        if (handlers.current.get(id) === entry) handlers.current.delete(id);
      };
    },
    []
  );
  const onBackPress = useCallback(() => {
    const entries = [...handlers.current.values()].sort(
      (a, b) => b.priority - a.priority || b.order - a.order
    );
    return entries.some(({ handler }) => handler());
  }, []);
  useAndroidBackHandler(onBackPress);
  const backHandlerContext = useMemo(
    () => ({ register: registerBackHandler }),
    [registerBackHandler]
  );
  return (
    <SharedElementContext.Provider value={sharedElementContext}>
      <ModalSetStateProvider.Provider value={setState}>
        <ModalStateProvider.Provider value={state}>
          <ModalBackHandlerProvider.Provider value={backHandlerContext}>
            {children}
            <ModalHost />
          </ModalBackHandlerProvider.Provider>
        </ModalStateProvider.Provider>
      </ModalSetStateProvider.Provider>
    </SharedElementContext.Provider>
  );
};
