import { type Dispatch, type SetStateAction } from 'react';
import type { IModalRegistry } from '../components/modal/types';
export interface ModalBackHandlerContextValue {
    register: (id: string, priority: number, handler: () => boolean) => () => void;
}
export declare const ModalStateProvider: import("react").Context<IModalRegistry>;
export declare const ModalSetStateProvider: import("react").Context<Dispatch<SetStateAction<IModalRegistry>> | null>;
export declare const ModalBackHandlerProvider: import("react").Context<ModalBackHandlerContextValue | null>;
//# sourceMappingURL=context.d.ts.map