# React Native Epic Modal

A **flexible**, **lightweight**, and **powerful** modal manager for React Native apps.  
Supports **stacking**, **custom animations**, **gesture dismissals**, and **portal-based** rendering — designed for smooth and modern mobile UX.

---

## ✨ Features

- 🎯 Portal-based rendering (modals independent of navigation tree)
- 🎯 Swipe-to-dismiss gestures with configurable areas
- 🎯 Built-in animations: `fade`, `slide`, `zoom`
- 🎯 Priority stacking for layered modals
- 🎯 Full control via `show()` and `hide()` programmatically
- 🎯 TypeScript support out of the box
- 🎯 Lightweight and mobile-first

---

## 📦 Installation

```bash
npm install react-native-epic-modal react-native-gesture-handler react-native-reanimated react-native-screens react-native-worklets
```

or

```bash
yarn add react-native-epic-modal react-native-gesture-handler react-native-reanimated react-native-screens react-native-worklets
```

> **Note:**  
> Make sure `react-native-reanimated` is configured correctly with the Babel plugin:  
> See [Reanimated installation guide](https://docs.swmansion.com/react-native-reanimated/docs/fundamentals/installation/).

---

## 🚀 Basic Usage

### 1. Wrap your app with `ModalProvider`

```tsx
import { ModalProvider } from 'react-native-epic-modal';

export default function App() {
  return <ModalProvider>{/* Your App Content */}</ModalProvider>;
}
```

---

### 2. Use `Modal` anywhere in your app

```tsx
import { Modal } from 'react-native-epic-modal';
import { useRef } from 'react';
import { Button, Text } from 'react-native';

export default function Screen() {
  const modalRef = useRef(null);

  return (
    <>
      <Button title="Open Modal" onPress={() => modalRef.current?.show()} />

      <Modal
        ref={modalRef}
        name="example-modal"
        animation="zoom"
        gestureEnabled
      >
        <Text>Modal Content Here!</Text>
      </Modal>
    </>
  );
}
```

---

## ⚙️ Modal Props

| Prop                                    | Type                            | Default           | Description                                                           |
| :-------------------------------------- | :------------------------------ | :---------------- | :-------------------------------------------------------------------- |
| `name`                                  | `string`                        | —                 | Unique registry name within the provider                              |
| `id`                                    | `string`                        | `name`            | Optional explicit registry ID                                         |
| `animation`                             | `"fade"` / `"slide"` / `"zoom"` | `"fade"`          | Modal entrance and exit animation                                     |
| `gestureEnabled`                        | `boolean`                       | `true`            | Enable swipe-to-dismiss gestures                                      |
| `animationDirection`                    | `"horizontal"` / `"vertical"`   | `"horizontal"`    | Direction of the modal presentation animation                         |
| `gestureConfig.edgeTarget`              | `"screen"` / `"content"`        | `"screen"`        | Whether the gesture edge is measured from the screen or modal content |
| `gestureConfig.gestureEdges`            | `TGestureEdge[]`                | `["left", "top"]` | Edges that can start the dismiss gesture; supports `"all"`            |
| `gestureConfig.leftGestureAreaOffset`   | `number`                        | `50`              | Width of the left horizontal gesture area                             |
| `gestureConfig.rightGestureAreaOffset`  | `number`                        | `0`               | Width of the right horizontal gesture area                            |
| `gestureConfig.topGestureAreaOffset`    | `number`                        | `200`             | Height of the top vertical gesture area                               |
| `gestureConfig.bottomGestureAreaOffset` | `number`                        | `0`               | Height of the bottom vertical gesture area                            |
| `priority`                              | `number`                        | `1`               | Stacking priority between multiple modals                             |
| `onEnter`                               | `() => void`                    | —                 | Callback when modal appears                                           |
| `onDismiss`                             | `() => void`                    | —                 | Callback when modal is dismissed                                      |
| `animationConfig`                       | `SpringConfig` (Reanimated)     | —                 | Customize entrance/exit spring behavior                               |
| `gestureConfig`                         | `IGestureConfig`                | —                 | Customize gesture sensitive areas and thresholds                      |

---

## ✍️ Example Gesture Config

```tsx
gestureConfig={{
  edgeTarget: "content",
  gestureEdges: ["left", "right", "top"],
  leftGestureAreaOffset: 50,
  rightGestureAreaOffset: 24,
  topGestureAreaOffset: 100,
  bottomGestureAreaOffset: 24,
  swipeVelocityThreshold: 800,
  swipeProgressToClose: "0.6"
}}

Use `gestureEdges: ["all"]` to enable all four edges.
```

## Animate Custom Content

Use `useProgress` inside a modal child to build an animation that follows the
modal presentation progress on the UI thread:

```tsx
import Animated, { useAnimatedStyle } from 'react-native-reanimated';
import { useProgress } from 'react-native-epic-modal';

function ModalContent() {
  const progress = useProgress();
  const style = useAnimatedStyle(() => ({
    transform: [{ translateY: (1 - progress.value) * 24 }],
    opacity: progress.value,
  }));

  return <Animated.View style={style}>{/* content */}</Animated.View>;
}
```

`useProgress` must be called from a component rendered inside `Modal`.

## Shared Element Prototype

`SharedElement` measures a native wrapper in window coordinates. Use a second,
non-interactive shadow wrapper for the destination layout, then render the
visual copy through `SharedElementTransition`. Set `trackFrame` on elements
inside scrolling containers; `throttle` controls the minimum interval between
native frame events in milliseconds:

```tsx
import {
  SharedElement,
  SharedElementTransition,
  useProgress,
} from 'react-native-epic-modal';

function SharedCard() {
  const progress = useProgress();

  return (
    <>
      <SharedElement id="card-source" trackFrame throttle={32}>
        <Card />
      </SharedElement>

      <SharedElement id="card-destination" measurementOnly>
        <Card />
      </SharedElement>

      <SharedElementTransition
        startId="card-source"
        endId="card-destination"
        progress={progress}
        clip={false}
      >
        <Card />
      </SharedElementTransition>
    </>
  );
}
```

The transition layer always uses `pointerEvents="none"`. The destination
shadow is transparent and non-interactive, so it can provide the final native
layout without intercepting touches. `onReady` fires once after both rects are
available; `onTransitionStart` and `onTransitionEnd` expose the clone
lifecycle for controlling the real source and destination content.

On iOS and Android, the wrapper reports its window frame from the native view
layout callback. Web and unsupported native configurations use the regular
React Native measurement fallback.

---

## 🛠 Requirements

- React Native >= 0.71
- react-native-gesture-handler >= 2.0
- react-native-reanimated >= 3.16
- react-native-screens >= 3.0
- react-native-worklets >= 0.5

✅ Compatible with Expo, Bare React Native, and monorepo setups.

---

## 🤝 Contributing

We welcome contributions!  
Please read our [Contributing Guide](CONTRIBUTING.md) to learn how to help improve Epic Modal.

---

## 📄 License

MIT License © 2024 [Oleg Mazur](https://github.com/mazurGit)

---

> Built with ❤️ using [create-react-native-library](https://github.com/callstack/react-native-builder-bob)
