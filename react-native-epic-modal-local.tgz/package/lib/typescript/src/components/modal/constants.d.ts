import type { WithSpringConfig } from 'react-native-reanimated';
import type { IGestureConfig } from './types';
export declare const DEFAULT_ANIMATION_CONFIG: WithSpringConfig;
export declare const DEFAULT_GESTURE_CONFIG: Required<IGestureConfig>;
//# sourceMappingURL=constants.d.ts.map