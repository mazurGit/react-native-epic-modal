export declare const useSharedElementRegistry: () => import("../context/shared-element-context").SharedElementRegistryValue;
//# sourceMappingURL=use-shared-element-registry.d.ts.map