import { ModalManager } from '../store/modal-manager';
/** Subscribes a React component to registered modal entries. */
export declare const useModalEntries: (manager?: ModalManager) => readonly import("../store/modal-manager").StoredModalEntry[];
//# sourceMappingURL=use-modal-entries.d.ts.map