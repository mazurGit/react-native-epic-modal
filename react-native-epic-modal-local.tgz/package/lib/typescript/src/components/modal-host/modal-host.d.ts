export declare const ModalHost: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=modal-host.d.ts.map