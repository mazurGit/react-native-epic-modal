import type { SharedElementTransitionProps } from './types';
export declare function SharedElementTransition({ startId, endId, progress, children, clip, onReady, onTransitionStart, onTransitionEnd, }: SharedElementTransitionProps): import("react/jsx-runtime").JSX.Element | null;
export declare function SharedElementTransitionView({ startId, endId, progress, children, clip, onReady, onTransitionStart, onTransitionEnd, }: SharedElementTransitionProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=shared-element-transition.d.ts.map