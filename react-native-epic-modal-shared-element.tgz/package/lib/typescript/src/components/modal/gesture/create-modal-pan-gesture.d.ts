import { type GestureType } from 'react-native-gesture-handler';
import type { ResolvedModalGestureConfig } from './modal-gesture';
import type { ModalGestureRuntime } from './modal-gesture-runtime';
type CreateModalPanGestureOptions = {
    width: number;
    height: number;
    config: ResolvedModalGestureConfig;
    runtime: ModalGestureRuntime;
    onDismissRequest?: () => void;
};
export declare const createModalPanGesture: (options: CreateModalPanGestureOptions) => GestureType;
export {};
//# sourceMappingURL=create-modal-pan-gesture.d.ts.map