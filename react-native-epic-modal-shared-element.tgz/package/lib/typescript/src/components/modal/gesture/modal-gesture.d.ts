export type ModalGestureEdge = 'left' | 'right' | 'top' | 'bottom';
export type ModalGestureDismissBehavior = 'settle' | 'followGesture';
export type ModalGestureConfig = {
    enabled?: boolean;
    immersive?: boolean;
    dismissBehavior?: ModalGestureDismissBehavior;
    edges?: Partial<Record<ModalGestureEdge, number>>;
    swipeVelocityThreshold?: number;
    swipeProgressToClose?: number;
};
export type ResolvedModalGestureConfig = Required<Omit<ModalGestureConfig, 'edges'>> & {
    edges: Required<NonNullable<ModalGestureConfig['edges']>>;
    immersive: boolean;
};
export declare const DEFAULT_MODAL_GESTURE: Required<Omit<ModalGestureConfig, 'edges'>> & {
    edges: Required<NonNullable<ModalGestureConfig['edges']>>;
};
export declare const resolveModalGestureConfig: (config?: ModalGestureConfig) => ResolvedModalGestureConfig;
//# sourceMappingURL=modal-gesture.d.ts.map