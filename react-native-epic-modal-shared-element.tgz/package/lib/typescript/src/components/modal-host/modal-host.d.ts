export type ModalHostProps = Record<never, never>;
/** Root layer for content rendered by the modal system. */
export declare const ModalHost: (_props: ModalHostProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=modal-host.d.ts.map