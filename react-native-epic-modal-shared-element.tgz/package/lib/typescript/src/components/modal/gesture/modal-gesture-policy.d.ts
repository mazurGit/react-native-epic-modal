import type { ModalGestureEdge } from './modal-gesture';
export type EdgeOffsets = Required<Record<ModalGestureEdge, number>>;
export declare const getActiveEdge: (x: number, y: number, width: number, height: number, offsets: EdgeOffsets) => ModalGestureEdge | null;
export declare const getAxisForEdge: (edge: ModalGestureEdge) => "x" | "y";
export declare const getEdgeDirection: (edge: ModalGestureEdge) => 1 | -1;
export declare const getProgress: (translation: number, distance: number, direction: number) => number;
export declare const shouldDismiss: (progress: number, dismissVelocity: number, progressThreshold: number, velocityThreshold: number) => boolean;
//# sourceMappingURL=modal-gesture-policy.d.ts.map