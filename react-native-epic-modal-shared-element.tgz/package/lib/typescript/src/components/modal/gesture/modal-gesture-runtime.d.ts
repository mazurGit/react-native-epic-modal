import { type SharedValue } from 'react-native-reanimated';
import type { ModalGestureEdge } from './modal-gesture';
export type ModalGesturePhase = 'idle' | 'tracking' | 'settling' | 'dismissing';
export type ModalGestureRuntime = {
    phase: SharedValue<ModalGesturePhase>;
    edge: SharedValue<ModalGestureEdge | 'immersive' | null>;
    axis: SharedValue<'x' | 'y' | null>;
    progress: SharedValue<number>;
    translationX: SharedValue<number>;
    translationY: SharedValue<number>;
    gestureActive: SharedValue<boolean>;
};
export declare const useModalGestureRuntime: (progress: SharedValue<number>) => ModalGestureRuntime;
//# sourceMappingURL=modal-gesture-runtime.d.ts.map