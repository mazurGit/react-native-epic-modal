export declare const useModalsContext: () => import("..").IModalRegistry;
//# sourceMappingURL=use-modals-context.d.ts.map