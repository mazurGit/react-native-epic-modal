export declare const useModalController: (id: string) => {
    visible: boolean;
    exiting: boolean;
    present: () => void;
    dismiss: () => void;
    completeDismiss: () => void;
};
//# sourceMappingURL=use-modal-controller.d.ts.map