import { type SharedValue } from 'react-native-reanimated';
type UseModalAnimationOptions = {
    exiting: boolean;
    duration: number;
    onExitComplete?: () => void;
};
export declare const useModalAnimation: ({ exiting, duration, onExitComplete, }: UseModalAnimationOptions) => SharedValue<number>;
export {};
//# sourceMappingURL=use-modal-animation.d.ts.map