import { type DependencyList } from 'react';
export declare const useAndroidBackHandler: (onBackPress: () => boolean, deps?: DependencyList) => void;
//# sourceMappingURL=use-android-back-handler.d.ts.map