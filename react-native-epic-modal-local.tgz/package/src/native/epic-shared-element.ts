import {
  requireNativeComponent,
  type NativeSyntheticEvent,
  type ViewProps,
} from 'react-native';
import type { SharedElementRect } from '../components/shared-element/types';

export interface NativeSharedElementProps extends ViewProps {
  /** Minimum interval between native frame events, in milliseconds. */
  throttle?: number;
  trackFrame?: boolean;
  onFrame?: (event: NativeSyntheticEvent<SharedElementRect>) => void;
}

export const NativeSharedElement =
  requireNativeComponent<NativeSharedElementProps>('EpicSharedElementView');
