import { type PropsWithChildren } from 'react';
import type { LayoutChangeEvent } from 'react-native';
import type { ModalBridgeProps, ModalRef } from '../modal-bridge/modal-bridge';
export type SharedElementModalProps = PropsWithChildren<Omit<ModalBridgeProps, 'hidden' | 'onLayout'> & {
    onLayout?: (event: LayoutChangeEvent) => void;
}>;
export type SharedElementModalRef = ModalRef;
/** Measures its content once before the modal is presented to the user. */
export declare const SharedElementModal: import("react").ForwardRefExoticComponent<Omit<ModalBridgeProps, "hidden" | "onLayout"> & {
    onLayout?: (event: LayoutChangeEvent) => void;
} & {
    children?: import("react").ReactNode | undefined;
} & import("react").RefAttributes<ModalRef>>;
//# sourceMappingURL=shared-element-modal.d.ts.map