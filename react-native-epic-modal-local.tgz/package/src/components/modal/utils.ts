import { interpolate, type SharedValue } from 'react-native-reanimated';
import type { ViewStyle } from 'react-native';
import type { TAnimation, TDirection, TGestureEdge } from './types';

export interface GestureBounds {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

export interface GestureEdgeOffsets {
  left: number;
  right: number;
  top: number;
  bottom: number;
}

export interface GestureEdgeMatch {
  axis: TDirection;
  sign: -1 | 1;
}

export const getGestureEdge = (
  x: number,
  y: number,
  bounds: GestureBounds,
  edges: readonly TGestureEdge[],
  offsets: GestureEdgeOffsets
): GestureEdgeMatch | null => {
  'worklet';

  const allEdgesEnabled = edges.includes('all');
  const isEnabled = (edge: TGestureEdge) =>
    allEdgesEnabled || edges.includes(edge);

  if (
    isEnabled('left') &&
    x >= bounds.left &&
    x <= Math.min(bounds.left + offsets.left, bounds.right)
  ) {
    return { axis: 'horizontal', sign: 1 };
  }
  if (
    isEnabled('right') &&
    x >= Math.max(bounds.left, bounds.right - offsets.right) &&
    x <= bounds.right
  ) {
    return { axis: 'horizontal', sign: -1 };
  }
  if (
    isEnabled('top') &&
    y >= bounds.top &&
    y <= Math.min(bounds.top + offsets.top, bounds.bottom)
  ) {
    return { axis: 'vertical', sign: 1 };
  }
  if (
    isEnabled('bottom') &&
    y >= Math.max(bounds.top, bounds.bottom - offsets.bottom) &&
    y <= bounds.bottom
  ) {
    return { axis: 'vertical', sign: -1 };
  }

  return null;
};

export const getAnimationConfig = (
  progress: SharedValue<number>,
  direction: TDirection,
  width: number,
  height: number
): Record<TAnimation, ViewStyle> => {
  'worklet';

  const isHorizontalDirection = direction === 'horizontal';
  return {
    none: {},
    zoom: {
      transform: [{ scale: progress.value }],
      opacity: progress.value,
    },
    slide: {
      transform: [
        isHorizontalDirection
          ? {
              translateX: interpolate(progress.value, [0, 1], [width, 0]),
            }
          : {
              translateY: interpolate(progress.value, [0, 1], [height, 0]),
            },
      ],
    },
    fade: {
      opacity: progress.value,
    },
  };
};
