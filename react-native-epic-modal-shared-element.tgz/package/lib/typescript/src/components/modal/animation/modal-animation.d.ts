export type ModalEnteringAnimationPreset = 'fade' | 'zoom' | 'slideLeft' | 'slideRight' | 'slideTop' | 'slideBottom';
export type ModalExitingAnimationPreset = ModalEnteringAnimationPreset | 'slideFree';
export type ModalAnimationPreset = ModalExitingAnimationPreset;
export interface ModalAnimationConfig {
    entering?: ModalEnteringAnimationPreset;
    exiting?: ModalExitingAnimationPreset;
    duration?: number;
}
export declare const DEFAULT_MODAL_ANIMATION: Required<ModalAnimationConfig>;
//# sourceMappingURL=modal-animation.d.ts.map