import type { IModalProps, IModalRef } from './types';
declare const ModalBridge: import("react").ForwardRefExoticComponent<IModalProps & {
    children?: import("react").ReactNode | undefined;
} & import("react").RefAttributes<IModalRef>>;
export { ModalBridge as Modal };
//# sourceMappingURL=modal-bridge.d.ts.map