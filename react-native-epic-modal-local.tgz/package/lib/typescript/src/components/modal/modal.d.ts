import type { IModalProps, IModalRef } from './types';
export declare const ModalContent: import("react").ForwardRefExoticComponent<IModalProps & {
    children?: import("react").ReactNode | undefined;
} & import("react").RefAttributes<IModalRef>>;
//# sourceMappingURL=modal.d.ts.map