import type { ReactNode, Ref } from 'react';
import { ViewStyle, StyleProp } from 'react-native';

export interface IModalComponent {
  id: string;
  props: IModalProps;
  ref: Ref<IModalRef>;
}

export interface IModalRegistry {
  byId: Record<string, IModalComponent>;
  order: string[];
}

export type TAnimation = 'none' | 'fade' | 'slide' | 'zoom';

export type TDirection = 'horizontal' | 'vertical';

export type TGestureEdge = 'left' | 'right' | 'top' | 'bottom' | 'all';

export interface IModalRef {
  show: () => void;
  hide: () => void;
}

export interface IGestureConfig {
  edgeTarget?: 'screen' | 'content';
  gestureEdges?: readonly TGestureEdge[];
  leftGestureAreaOffset?: number;
  rightGestureAreaOffset?: number;
  topGestureAreaOffset?: number;
  bottomGestureAreaOffset?: number;
  swipeVelocityThreshold?: number;
  swipeProgressToClose?: `0.${number}`;
}

export interface IModalProps {
  name: string;
  children?: ReactNode;
  id?: string;
  onEnter?: () => void;
  onDismiss?: () => void;
  style?: StyleProp<ViewStyle>;
  animation?: TAnimation;
  animationDirection?: 'horizontal' | 'vertical';
  gestureEnabled?: boolean;
  priority?: number;
  animationConfig?: SpringConfig;
  gestureConfig?: IGestureConfig;
  hiddenStatusBar?: boolean;
}
