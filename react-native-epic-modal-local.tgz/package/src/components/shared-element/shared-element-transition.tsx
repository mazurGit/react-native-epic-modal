import Animated, {
  Extrapolation,
  interpolate,
  useAnimatedReaction,
  useAnimatedStyle,
  useSharedValue,
} from 'react-native-reanimated';
import { StyleSheet } from 'react-native';
import { scheduleOnRN } from 'react-native-worklets';
import { useContext, useEffect, useRef } from 'react';
import type { SharedElementRect, SharedElementTransitionProps } from './types';
import { useSharedElementRegistry } from '../../hooks/use-shared-element-registry';
import { ModalTransitionContext } from '../../context/modal-transition-context';

export function SharedElementTransition({
  startId,
  endId,
  progress,
  children,
  clip = true,
  onReady,
  onTransitionStart,
  onTransitionEnd,
}: SharedElementTransitionProps) {
  const modalTransitionContext = useContext(ModalTransitionContext);
  const transitionKeyRef = useRef(`transition-${Math.random()}`);

  useEffect(() => {
    if (!modalTransitionContext) return;
    const key = transitionKeyRef.current;
    modalTransitionContext.register({
      key,
      startId,
      endId,
      progress,
      children,
      clip,
      onReady,
      onTransitionStart,
      onTransitionEnd,
    });
    return () => modalTransitionContext.unregister(key);
  }, [
    children,
    clip,
    endId,
    modalTransitionContext,
    onReady,
    onTransitionEnd,
    onTransitionStart,
    progress,
    startId,
  ]);

  if (modalTransitionContext) return null;

  return (
    <SharedElementTransitionView
      startId={startId}
      endId={endId}
      progress={progress}
      clip={clip}
      onReady={onReady}
      onTransitionStart={onTransitionStart}
      onTransitionEnd={onTransitionEnd}
    >
      {children}
    </SharedElementTransitionView>
  );
}

export function SharedElementTransitionView({
  startId,
  endId,
  progress,
  children,
  clip = true,
  onReady,
  onTransitionStart,
  onTransitionEnd,
}: SharedElementTransitionProps) {
  const { get, revision } = useSharedElementRegistry();
  const startNode = get(startId);
  const endNode = get(endId);
  const endMeasurementNode = get(endId, true) ?? endNode;
  const start = startNode?.rect;
  const end = endMeasurementNode?.rect;
  const startSnapshot = useSharedValue<SharedElementRect | null>(null);
  const endSnapshot = useSharedValue<SharedElementRect | null>(null);

  useAnimatedReaction(
    () => Boolean(start?.value && end?.value),
    (isReady, wasReady) => {
      if (isReady && !wasReady) {
        if (onReady) {
          scheduleOnRN(onReady);
        }
      }
    },
    [revision, onReady]
  );

  useAnimatedReaction(
    () => {
      const hasRects = Boolean(start?.value && end?.value);
      return {
        isActive: hasRects && progress.value > 0.001 && progress.value < 0.999,
        isComplete: hasRects && progress.value >= 0.999,
      };
    },
    ({ isActive, isComplete }, previous) => {
      if (isActive && !previous?.isActive) {
        const nextStart = start?.value ?? null;
        const nextEnd = end?.value ?? null;
        startSnapshot.value = nextStart;
        endSnapshot.value = nextEnd;
      } else if (
        !isActive &&
        !isComplete &&
        (previous?.isActive || previous?.isComplete)
      ) {
        startSnapshot.value = null;
        endSnapshot.value = null;
      }
      if (isActive && !previous?.isActive && onTransitionStart) {
        scheduleOnRN(onTransitionStart);
      } else if (isComplete && !previous?.isComplete && onTransitionEnd) {
        scheduleOnRN(onTransitionEnd);
      }
    },
    [revision, onTransitionStart, onTransitionEnd]
  );

  useAnimatedReaction(
    () => progress.value,
    (currentProgress) => {
      if (startNode?.visibility) {
        startNode.visibility.value = interpolate(
          currentProgress,
          [0, 0.001, 0.002],
          [1, 1, 0],
          Extrapolation.CLAMP
        );
      }
      if (endNode?.visibility) {
        endNode.visibility.value = interpolate(
          currentProgress,
          [0.9, 1],
          [0, 1],
          Extrapolation.CLAMP
        );
      }
    },
    [revision]
  );

  const animatedStyle = useAnimatedStyle(() => {
    const startRect = startSnapshot.value;
    const endRect = endSnapshot.value;
    if (!startRect || !endRect) {
      return { opacity: 0 };
    }

    return {
      opacity: 1,
      left: interpolate(progress.value, [0, 1], [startRect.x, endRect.x]),
      top: interpolate(progress.value, [0, 1], [startRect.y, endRect.y]),
      width: interpolate(
        progress.value,
        [0, 1],
        [startRect.width, endRect.width]
      ),
      height: interpolate(
        progress.value,
        [0, 1],
        [startRect.height, endRect.height]
      ),
    };
  }, [revision, start, end]);

  return (
    <Animated.View
      pointerEvents="none"
      style={[styles.element, clip && styles.clipped, animatedStyle]}
    >
      {children}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  element: {
    position: 'absolute',
  },
  clipped: {
    overflow: 'hidden',
  },
});
