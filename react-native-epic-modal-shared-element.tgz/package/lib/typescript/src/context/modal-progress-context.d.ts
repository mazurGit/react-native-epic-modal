import type { SharedValue } from 'react-native-reanimated';
export declare const ModalProgressContext: import("react").Context<SharedValue<number> | null>;
//# sourceMappingURL=modal-progress-context.d.ts.map