import { type PropsWithChildren } from 'react';
import type { ReactElement } from 'react';
import { type StyleProp, type ViewProps, type ViewStyle } from 'react-native';
export interface SharedElementProps {
    id: string;
    measurementOnly?: boolean;
    throttle?: number;
    trackFrame?: boolean;
    pointerEvents?: ViewProps['pointerEvents'];
    style?: StyleProp<ViewStyle>;
}
export declare function SharedElement({ id, measurementOnly, throttle, trackFrame, pointerEvents, style, children, }: PropsWithChildren<SharedElementProps & {
    children: ReactElement;
}>): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=shared-element.d.ts.map