import type { SharedElementTransitionProps } from '../components/shared-element/types';
export interface ModalTransitionDescriptor extends SharedElementTransitionProps {
    key: string;
}
export interface ModalTransitionContextValue {
    register: (transition: ModalTransitionDescriptor) => void;
    unregister: (key: string) => void;
}
export declare const ModalTransitionContext: import("react").Context<ModalTransitionContextValue | null>;
//# sourceMappingURL=modal-transition-context.d.ts.map