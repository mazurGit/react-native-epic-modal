import type { RefObject } from 'react';
import type { ModalBridgeProps, ModalRef } from '../components/modal-bridge/modal-bridge';
type Listener = () => void;
export type StoredModalEntry = {
    id: string;
    props: ModalBridgeProps;
    ref: RefObject<ModalRef | null>;
    presentationOrder: number;
};
type ModalRegistration = Pick<StoredModalEntry, 'id' | 'props' | 'ref'>;
/** External store responsible for the modal collection and its ordering. */
export declare class ModalManager {
    private static instance;
    private readonly entries;
    private readonly listeners;
    private nextPresentationOrder;
    private snapshot;
    private constructor();
    static getInstance(): ModalManager;
    subscribe: (listener: Listener) => () => boolean;
    getSnapshot: () => readonly StoredModalEntry[];
    register: (registration: ModalRegistration) => () => void;
    unregister: (id: string, ref?: RefObject<ModalRef | null>) => void;
    present: (id: string) => void;
    clear: () => void;
    private updateSnapshot;
}
export declare const modalManager: ModalManager;
export {};
//# sourceMappingURL=modal-manager.d.ts.map