import { type PropsWithChildren } from 'react';
import type { LayoutChangeEvent, StyleProp, ViewStyle } from 'react-native';
import type { ModalAnimationConfig } from '../modal/animation/modal-animation';
import type { ModalGestureConfig } from '../modal/gesture/modal-gesture';
export interface ModalRef {
    present: () => void;
    dismiss: () => void;
}
export type ModalBridgeProps = PropsWithChildren<{
    style?: StyleProp<ViewStyle>;
    backdropStyle?: StyleProp<ViewStyle>;
    animation?: ModalAnimationConfig;
    gestureConfig?: ModalGestureConfig;
    hidden?: boolean;
    keepMounted?: boolean;
    onLayout?: (event: LayoutChangeEvent) => void;
}>;
/** Bridges React modal props and ref actions to the external modal manager. */
export declare const ModalBridge: import("react").ForwardRefExoticComponent<{
    style?: StyleProp<ViewStyle>;
    backdropStyle?: StyleProp<ViewStyle>;
    animation?: ModalAnimationConfig;
    gestureConfig?: ModalGestureConfig;
    hidden?: boolean;
    keepMounted?: boolean;
    onLayout?: (event: LayoutChangeEvent) => void;
} & {
    children?: import("react").ReactNode | undefined;
} & import("react").RefAttributes<ModalRef>>;
//# sourceMappingURL=modal-bridge.d.ts.map