import { type PropsWithChildren } from 'react';
import { type LayoutChangeEvent, type StyleProp, type ViewStyle } from 'react-native';
import { type ModalAnimationConfig } from './animation/modal-animation';
import type { ModalGestureConfig } from './gesture/modal-gesture';
export type ModalViewProps = PropsWithChildren<{
    style?: StyleProp<ViewStyle>;
    backdropStyle?: StyleProp<ViewStyle>;
    animation?: ModalAnimationConfig;
    gestureConfig?: ModalGestureConfig;
    exiting?: boolean;
    onExitComplete?: () => void;
    onDismissRequest?: () => void;
    hidden?: boolean;
    onLayout?: (event: LayoutChangeEvent) => void;
}>;
/** Modal surface. Its progress is shared with modal content and future gestures. */
export declare const ModalView: ({ children, style, backdropStyle, animation, gestureConfig, exiting, onExitComplete, onDismissRequest, hidden, onLayout, }: ModalViewProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=modal-view.d.ts.map