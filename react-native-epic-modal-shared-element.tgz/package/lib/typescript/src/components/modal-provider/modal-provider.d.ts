import { type PropsWithChildren } from 'react';
export type ModalProviderProps = PropsWithChildren;
/** Provides the app-level modal integration point and mounts the modal host. */
export declare const ModalProvider: ({ children }: ModalProviderProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=modal-provider.d.ts.map