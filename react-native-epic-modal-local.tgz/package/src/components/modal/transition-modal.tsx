import { forwardRef, type PropsWithChildren, type ReactNode } from 'react';
import type { IModalProps, IModalRef } from './types';
import { Modal } from './modal-bridge';
import { SharedElementTransition } from '../shared-element/shared-element-transition';
import type { SharedElementTransitionProps } from '../shared-element/types';
import { useProgress } from '../../hooks/use-progress';

export type TransitionModalItem = Omit<
  SharedElementTransitionProps,
  'progress'
> & {
  key: string;
};

export interface TransitionModalProps extends Omit<IModalProps, 'children'> {
  children?: ReactNode;
  transitions?: readonly TransitionModalItem[];
}

export const TransitionModal = forwardRef<
  IModalRef,
  PropsWithChildren<TransitionModalProps>
>(({ children, transitions = [], ...modalProps }, ref) => {
  return (
    <Modal ref={ref} {...modalProps}>
      <TransitionModalContent transitions={transitions}>
        {children}
      </TransitionModalContent>
    </Modal>
  );
});

function TransitionModalContent({
  children,
  transitions,
}: {
  children?: ReactNode;
  transitions: readonly TransitionModalItem[];
}) {
  const progress = useProgress();

  return (
    <>
      {children}
      {transitions.map(({ key, ...transition }) => (
        <SharedElementTransition
          key={key}
          {...transition}
          progress={progress}
        />
      ))}
    </>
  );
}
