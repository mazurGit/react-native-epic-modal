import type { WithSpringConfig } from 'react-native-reanimated';
import type { IGestureConfig } from './types';

export const DEFAULT_ANIMATION_CONFIG: WithSpringConfig = {
  damping: 100,
  stiffness: 500,
};

export const DEFAULT_GESTURE_CONFIG: Required<IGestureConfig> = {
  edgeTarget: 'screen',
  gestureEdges: ['left', 'top'],
  leftGestureAreaOffset: 50,
  rightGestureAreaOffset: 0,
  topGestureAreaOffset: 200,
  bottomGestureAreaOffset: 0,
  swipeVelocityThreshold: 800,
  swipeProgressToClose: `0.6`,
};
