import { type PropsWithChildren } from 'react';
import type { LayoutChangeEvent, StyleProp, ViewStyle } from 'react-native';
import type { ModalAnimationConfig } from './animation/modal-animation';
import type { ModalGestureConfig } from './gesture/modal-gesture';
export type ModalContentProps = PropsWithChildren<{
    id: string;
    style?: StyleProp<ViewStyle>;
    backdropStyle?: StyleProp<ViewStyle>;
    animation?: ModalAnimationConfig;
    gestureConfig?: ModalGestureConfig;
    hidden?: boolean;
    onLayout?: (event: LayoutChangeEvent) => void;
}>;
export interface ModalContentRef {
    present: () => void;
    dismiss: () => void;
}
export declare const ModalContent: import("react").ForwardRefExoticComponent<{
    id: string;
    style?: StyleProp<ViewStyle>;
    backdropStyle?: StyleProp<ViewStyle>;
    animation?: ModalAnimationConfig;
    gestureConfig?: ModalGestureConfig;
    hidden?: boolean;
    onLayout?: (event: LayoutChangeEvent) => void;
} & {
    children?: import("react").ReactNode | undefined;
} & import("react").RefAttributes<ModalContentRef>>;
//# sourceMappingURL=modal-content.d.ts.map