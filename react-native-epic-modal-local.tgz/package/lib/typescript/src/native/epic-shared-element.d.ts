import { type NativeSyntheticEvent, type ViewProps } from 'react-native';
import type { SharedElementRect } from '../components/shared-element/types';
export interface NativeSharedElementProps extends ViewProps {
    /** Minimum interval between native frame events, in milliseconds. */
    throttle?: number;
    trackFrame?: boolean;
    onFrame?: (event: NativeSyntheticEvent<SharedElementRect>) => void;
}
export declare const NativeSharedElement: import("react-native").HostComponent<NativeSharedElementProps>;
//# sourceMappingURL=epic-shared-element.d.ts.map