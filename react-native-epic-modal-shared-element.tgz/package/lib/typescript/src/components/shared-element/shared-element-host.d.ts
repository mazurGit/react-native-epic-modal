import { View, type StyleProp, type ViewProps, type ViewStyle } from 'react-native';
export interface SharedElementHostProps extends ViewProps {
    style?: StyleProp<ViewStyle>;
}
/** Provides the native ancestor tag used by shared-element measurements. */
export declare const SharedElementHost: import("react").ForwardRefExoticComponent<SharedElementHostProps & {
    children?: import("react").ReactNode | undefined;
} & import("react").RefAttributes<View>>;
//# sourceMappingURL=shared-element-host.d.ts.map