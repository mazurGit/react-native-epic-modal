export declare const SharedElementHostContext: import("react").Context<number | null>;
//# sourceMappingURL=shared-element-host-context.d.ts.map