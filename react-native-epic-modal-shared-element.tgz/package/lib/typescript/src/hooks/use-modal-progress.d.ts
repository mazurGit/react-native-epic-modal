/** Returns the shared transition progress of the nearest modal. */
export declare const useModalProgress: () => import("react-native-reanimated").SharedValue<number>;
//# sourceMappingURL=use-modal-progress.d.ts.map