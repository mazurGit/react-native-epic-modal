jest.mock('react-native-reanimated', () => ({
  interpolate: (value: number, input: number[], output: number[]) =>
    output[0]! +
    ((value - input[0]!) / (input[1]! - input[0]!)) * (output[1]! - output[0]!),
}));

import { getAnimationConfig, getGestureEdge } from './utils';

describe('getAnimationConfig', () => {
  const progress = { value: 0.5 } as never;

  it('uses the measured height for a vertical slide', () => {
    const styles = getAnimationConfig(progress, 'vertical', 390, 844);

    expect(styles.slide).toEqual({
      transform: [{ translateY: 422 }],
    });
  });

  it('uses the measured width for a horizontal slide', () => {
    const styles = getAnimationConfig(progress, 'horizontal', 390, 844);

    expect(styles.slide).toEqual({
      transform: [{ translateX: 195 }],
    });
  });

  it('maps progress to fade and zoom styles', () => {
    const styles = getAnimationConfig(progress, 'horizontal', 390, 844);

    expect(styles.fade).toEqual({ opacity: 0.5 });
    expect(styles.zoom).toEqual({
      transform: [{ scale: 0.5 }],
      opacity: 0.5,
    });
  });
});

describe('getGestureEdge', () => {
  const bounds = { left: 10, top: 20, right: 390, bottom: 820 };
  const offsets = { left: 40, right: 30, top: 80, bottom: 60 };

  it('detects horizontal edges', () => {
    expect(getGestureEdge(20, 400, bounds, ['left'], offsets)).toEqual({
      axis: 'horizontal',
      sign: 1,
    });
    expect(getGestureEdge(370, 400, bounds, ['right'], offsets)).toEqual({
      axis: 'horizontal',
      sign: -1,
    });
  });

  it('detects vertical edges', () => {
    expect(getGestureEdge(200, 30, bounds, ['top'], offsets)).toEqual({
      axis: 'vertical',
      sign: 1,
    });
    expect(getGestureEdge(200, 780, bounds, ['bottom'], offsets)).toEqual({
      axis: 'vertical',
      sign: -1,
    });
  });

  it('supports all edges and ignores disabled edges', () => {
    expect(getGestureEdge(370, 400, bounds, ['all'], offsets)).toEqual({
      axis: 'horizontal',
      sign: -1,
    });
    expect(getGestureEdge(370, 400, bounds, ['left'], offsets)).toBeNull();
  });
});
