import { type FC, type PropsWithChildren } from 'react';
export declare const ModalProvider: FC<PropsWithChildren>;
//# sourceMappingURL=modal-provider.d.ts.map