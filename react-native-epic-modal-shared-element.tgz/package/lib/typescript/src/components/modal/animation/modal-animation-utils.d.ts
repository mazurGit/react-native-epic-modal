import { type SharedValue } from 'react-native-reanimated';
import type { ViewStyle } from 'react-native';
import type { ModalEnteringAnimationPreset, ModalExitingAnimationPreset } from './modal-animation';
export declare const getModalAnimationStyle: (progress: SharedValue<number>, enteringPreset: ModalEnteringAnimationPreset, exitingPreset: ModalExitingAnimationPreset, exiting: boolean, gestureActive: SharedValue<boolean>, width: number, height: number, translationX: SharedValue<number>, translationY: SharedValue<number>) => ViewStyle;
//# sourceMappingURL=modal-animation-utils.d.ts.map