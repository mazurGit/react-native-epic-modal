import { type ReactNode } from 'react';
import type { IModalProps, IModalRef } from './types';
import type { SharedElementTransitionProps } from '../shared-element/types';
export type TransitionModalItem = Omit<SharedElementTransitionProps, 'progress'> & {
    key: string;
};
export interface TransitionModalProps extends Omit<IModalProps, 'children'> {
    children?: ReactNode;
    transitions?: readonly TransitionModalItem[];
}
export declare const TransitionModal: import("react").ForwardRefExoticComponent<TransitionModalProps & {
    children?: ReactNode | undefined;
} & import("react").RefAttributes<IModalRef>>;
//# sourceMappingURL=transition-modal.d.ts.map